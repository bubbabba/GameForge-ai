<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="floors" tilewidth="16" tileheight="16" tilecount="24" columns="8">
 <image source="../16x16/floors/floors.png" width="128" height="48"/>
</tileset>
