<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="walls" tilewidth="16" tileheight="16" tilecount="40" columns="8">
 <image source="../16x16/walls/walls.png" width="128" height="80"/>
</tileset>
