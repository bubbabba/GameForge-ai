POCKET TOWN - COZY INTERIORS  v1.0
by bubbabba

A 16x16 top-down interior pack for modern RPGs, life sims and cosy games.
Every sprite is provided at 16x16, 32x32 and 48x48.

CONTENTS
  floors/      22 seamless floor tiles (planks, herringbone, checker, tiles, carpets)
  walls/       17 wall tiles - 16x32 wall faces (wallpapers, tiles, brick, wainscot) + wall-top tile
  furniture/   85 furniture & decor sprites (beds, sofas, kitchen, bathroom, study, plants,
               rugs, windows, doors, paintings...). All aligned to the 16px grid.
  pets/        4 cats - 16x16, rows: down, left, right, up; 4 frames each
  characters/  8 residents - 16x32, rows: down, left, right, up; 4-frame walk
  tiled/       Tiled (.tsx) tilesets for floors and walls
  atlas.json   Sprite coordinates for _furniture_sheet.png
  sample_house.png  Example house built only from this pack

WALLS
  Each wall face is 16x32: the top 4px is the wall cap seen from above, then the wall,
  then the baseboard. Place the wall face on the row above your floor.

Matching pack: POCKET TOWN - MODERN EXTERIORS (same palette, scale and characters style).
