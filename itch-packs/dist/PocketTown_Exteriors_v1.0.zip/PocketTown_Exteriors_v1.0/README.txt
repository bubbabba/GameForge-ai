POCKET TOWN - MODERN EXTERIORS  v1.0
by bubbabba

A cosy top-down 16x16 pixel art pack for modern-day RPGs, life sims and town builders.
Every sprite is provided at 16x16, 32x32 and 48x48 (pixel-perfect nearest-neighbour scaling).

CONTENTS
  terrain/            96 autotile & fill tiles (grass, dirt, sand, water, brick paving, sidewalk/curb)
                      Layout: 3x3 outer block + 2x2 inner corners + fill variants below.
  terrain/road_markings.png  16 road tiles (lanes, crosswalks, arrows, manhole, drain...)
  animated/           3-frame water animation
  buildings/          19 buildings (houses, shops, apartments, garages) - grid aligned
  props/              41 props (trees, bushes, fences, lamps, benches, signs, fountain, vending...)
  vehicles/           18 vehicles x 4 directions (sedan, van, pickup, taxi, police)
  characters/         20 premade characters (16x32, 4 directions x 4-frame walk)
  character_generator/ 105 layered parts: stack 1_bodies + 2_outfits + 3_hair to make your own
  tiled/              Tiled (.tsx) tilesets for the terrain sheets
  atlas.json          Sprite coordinates for the packed *_sheet.png files
  sample_map.png      Example scene built only from this pack

CHARACTER SHEETS
  64x128 px (at 16x16 scale). Frame 16x32. Rows: down, left, right, up. Columns: walk frames 0-3
  (frame 0 = idle). Suggested speed: 8 fps.

VEHICLE STRIPS
  128x32 px. Frame 32x32. Columns: down, left, right, up.

Matching pack: POCKET TOWN - COZY INTERIORS.
