<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="grass_dirt" tilewidth="16" tileheight="16" tilecount="20" columns="5">
 <image source="../16x16/terrain/grass_dirt.png" width="80" height="64"/>
</tileset>
