<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="road_markings" tilewidth="16" tileheight="16" tilecount="16" columns="8">
 <image source="../16x16/terrain/road_markings.png" width="128" height="32"/>
</tileset>
